const alunos = 10;

for (var index = 0; index <= 10; index++){

    if (index % 2 == 0){
        console.log(+index+ ' Par');
    }else if (index % 2 != 0){
        console.log(+index+ ' Impar');
    };
};
